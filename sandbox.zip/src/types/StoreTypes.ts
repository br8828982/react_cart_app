export interface StoreItem {
  id: number;
  name: string;
  price: number;
}
