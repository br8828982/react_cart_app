export interface CartItem {
  id: number;
  quantity: number;
}

export interface CartContextType {
  cartItems: CartItem[];
  addToCart: (id: number) => void;
}

export enum CartActionTypes {
  ADD_TO_CART = "ADD_TO_CART",
}

type PayloadType = {
  id: number;
};

interface AddToCartAction {
  type: CartActionTypes.ADD_TO_CART;
  payload: PayloadType;
}

export type CartAction = AddToCartAction;
