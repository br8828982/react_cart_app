import "./App.css";
import CartApp from "./components/CartApp";

function App() {
  return (
    <div className="App">
      <CartApp />
    </div>
  );
}

export default App;
