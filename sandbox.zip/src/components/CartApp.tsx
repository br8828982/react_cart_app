import { CartList } from "./CartList";
import { CartPrice } from "./CartPrice";
import { StoreList } from "./StoreList";

const CartApp = () => {
  return (
    <div>
      <h1>Shopping Cart</h1>
      <div>
        <h2>Product List</h2>
        <StoreList />
      </div>
      <div>
        <h2>Shopping Cart</h2>
        <CartList />
        <CartPrice />
      </div>
    </div>
  );
};

export default CartApp;
