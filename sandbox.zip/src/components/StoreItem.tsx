import { useCartContext } from "../hooks/useCartContext";
import { StoreItem } from "../types/StoreTypes";

export function StoreItem({ id, name, price }: StoreItem) {
  const { addToCart } = useCartContext();

  return (
    <li>
      {name} - ${price}{" "}
      <button onClick={() => addToCart(id)}>Add to Cart</button>
    </li>
  );
}
