import { useShoppingCart } from "../hooks/useCartContext";
import storeItems from "../data/items.ts";
import { CartItem } from "../types/CartTypes";
import { StoreItem } from "../types/StoreTypes";

export function CartItem({ id, quantity }: CartItem) {
  const { removeFromCart } = useShoppingCart();
  const item: StoreItem[] = storeItems.find((i) => i.id === id);
  if (item == null) return null;

  return (
    <div>
      <li key={item.id}>
        {item.name} - ${item.price} x {quantity} = $
        {item.price * quantity}
      </li>
    </div>
  );
}
