import { useCartContext } from "../hooks/useCartContext";
import { storeItems } from "../data/items";
import { CartItem } from "../types/CartTypes";

export function CartPrice() {
  const { cartItems } = useCartContext();

  const calculateTotal = (): number => {
    return cartItems.reduce((total: number, cartItem: CartItem) => {
      const item = storeItems.find((i) => i.id === cartItem.id);
      return total + (item?.price || 0) * cartItem.quantity;
    }, 0);
  };

  return <p>Total: ${calculateTotal()}</p>;
}
