import { StoreItem } from "./StoreItem";
import { storeItems } from "../data/items";

export function StoreList() {
  return (
    <>
      <h1>Store</h1>
      <ul>
        {storeItems.map((item) => (
          <StoreItem key={item.id} {...item} />
        ))}
      </ul>
    </>
  );
}
