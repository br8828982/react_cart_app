import { useCartContext } from "../hooks/useCartContext";
import { CartItem } from "./CartItem";

export function CartList() {
  const { cartItems } = useCartContext();
  return (
    <div>
      {cartItems.map((item) => (
        <CartItem key={item.id} {...item} />
      ))}
    </div>
  );
}
