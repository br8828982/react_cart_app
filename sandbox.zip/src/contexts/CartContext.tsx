import { createContext, ReactNode, useReducer } from "react";
import { CartActionTypes, CartContextType } from "../types/CartTypes";
import { cartReducer, initialState } from "../store/cartReducer";

type ShoppingCartProviderProps = {
  children: ReactNode;
};

export const CartContext = createContext<CartContextType | null>(null);

export function CartProvider({ children }: ShoppingCartProviderProps) {
  const [cartItems, dispatch] = useReducer(cartReducer, initialState);

  const addToCart = (id: number) => {
    dispatch({ type: CartActionTypes.ADD_TO_CART, payload: { id } });
  };

  const value: CartContextType = {
    cartItems,
    addToCart,
  };

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}
